import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:confetti/confetti.dart';

class MatchController extends GetxController with GetSingleTickerProviderStateMixin {
  late ConfettiController confettiController;
  late AnimationController animCtrl;
  late Animation<double> scaleAnim;

  @override
  void onInit() {
    super.onInit();
    // Logic hiệu ứng pháo hoa
    confettiController = ConfettiController(duration: const Duration(seconds: 2));
    confettiController.play();

    // Logic hiệu ứng xuất hiện của Dialog
    animCtrl = AnimationController(
      vsync: this, 
      duration: const Duration(milliseconds: 600)
    );
    scaleAnim = CurvedAnimation(parent: animCtrl, curve: Curves.backOut);
    animCtrl.forward();
  }

  @override
  void onClose() {
    confettiController.dispose();
    animCtrl.dispose();
    super.onClose();
  }
}
