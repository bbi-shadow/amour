import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/firestore_service.dart';
import '../utils/app_constants.dart';

class CallController extends GetxController {
  final String callId;
  final String otherUserId;
  final String otherUserName;
  final bool isVideo;
  final bool isIncoming;

  CallController({
    required this.callId,
    required this.otherUserId,
    required this.otherUserName,
    required this.isVideo,
    required this.isIncoming,
  });

  static CallController get to => Get.find();

  // -- Agora Config --
  final String _appId = "e60b853ab652045a6af74da86d5e9e304";
  final String _myId = FirebaseAuth.instance.currentUser?.uid ?? '';
  RtcEngine? engine;

  // -- States --
  final RxInt duration = 0.obs;
  final RxString status = 'calling'.obs;
  final RxBool isMuted = false.obs;
  final RxBool isCameraOff = false.obs;
  final RxBool isSpeaker = false.obs;
  final RxBool localUserJoined = false.obs;
  final RxInt? remoteUid = RxInt?(-1);
  final RxInt ringingCountdown = 10.obs;
  final RxBool callEnded = false.obs;
  final RxString endReason = ''.obs;

  Timer? _callTimer;
  Timer? _noAnswerTimer;
  Timer? _countdownTimer;
  StreamSubscription? _callSub;

  @override
  void onInit() {
    super.onInit();
    if (!isIncoming) {
      initAgora();
      _startNoAnswerTimer();
    }
    _listenToCallStatus();
  }

  @override
  void onClose() {
    _stopAllTimers();
    _callSub?.cancel();
    _releaseAgora();
    super.onClose();
  }

  // -- Agora Logic --
  Future<void> initAgora() async {
    if (engine != null) return;

    await [Permission.microphone, Permission.camera].request();

    engine = createAgoraRtcEngine();
    await engine!.initialize(RtcEngineContext(appId: _appId));

    engine!.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (connection, elapsed) {
          localUserJoined.value = true;
        },
        onUserJoined: (connection, rUid, elapsed) {
          _stopNoAnswerTimer();
          remoteUid.value = rUid;
          _startCallTimer();
        },
        onUserOffline: (connection, rUid, reason) {
          endCall(reason: 'ended');
        },
      ),
    );

    if (isVideo) {
      await engine!.enableVideo();
      await engine!.startPreview();
    } else {
      await engine!.enableAudio();
    }

    await engine!.joinChannel(
      token: "",
      channelId: callId,
      uid: 0,
      options: const ChannelMediaOptions(),
    );
  }

  void _releaseAgora() async {
    if (engine != null) {
      await engine!.leaveChannel();
      await engine!.release();
      engine = null;
    }
  }

  // -- Timers --
  void _startCallTimer() {
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => duration.value++);
  }

  void _startNoAnswerTimer() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      ringingCountdown.value--;
      if (ringingCountdown.value <= 0) t.cancel();
    });

    _noAnswerTimer = Timer(const Duration(seconds: 10), () => _handleNoAnswer());
  }

  void _stopNoAnswerTimer() {
    _noAnswerTimer?.cancel();
    _countdownTimer?.cancel();
  }

  void _stopAllTimers() {
    _callTimer?.cancel();
    _noAnswerTimer?.cancel();
    _countdownTimer?.cancel();
  }

  // -- Call Actions --
  Future<void> _handleNoAnswer() async {
    await endCall(reason: 'no_answer');
  }

  Future<void> acceptCall() async {
    _stopNoAnswerTimer();
    await FirestoreService.updateCallStatus(callId, 'accepted');
    await initAgora();
    _startCallTimer();
  }

  Future<void> rejectCall() async {
    _stopNoAnswerTimer();
    await FirestoreService.updateCallStatus(callId, 'rejected');
    await _writeCallMessage(status: 'rejected', duration: 0);
    Get.back();
  }

  Future<void> endCall({String reason = 'ended'}) async {
    if (callEnded.value) return;
    
    _stopAllTimers();
    final finalDuration = duration.value;
    
    await FirestoreService.updateCallStatus(callId, reason, duration: finalDuration);
    await _writeCallMessage(status: reason, duration: finalDuration);

    callEnded.value = true;
    endReason.value = reason;
    
    Future.delayed(const Duration(seconds: 2), () => Get.back());
  }

  // -- Firestore Messaging --
  void _listenToCallStatus() {
    _callSub = FirestoreService.watchCall(callId).listen((snap) {
      if (!snap.exists) return;
      final d = snap.data() as Map<String, dynamic>;
      final s = d['status'] as String;

      if (s == 'accepted' && isIncoming && engine == null) {
        _stopNoAnswerTimer();
      }

      if (s == 'ended' || s == 'rejected' || s == 'no_answer') {
        _handleRemoteEnd(s);
      }
    });
  }

  void _handleRemoteEnd(String s) {
    if (callEnded.value) return;
    _stopAllTimers();
    callEnded.value = true;
    endReason.value = s;
    Future.delayed(const Duration(seconds: 2), () => Get.back());
  }

  Future<void> _writeCallMessage({required String status, required int duration}) async {
    final convRef = FirebaseFirestore.instance.collection('conversations').doc(callId);
    final convSnap = await convRef.get();
    if (!convSnap.exists) return;

    String text = isVideo ? "Cuoc goi video" : "Cuoc goi thoai";
    if (status == 'no_answer') text += " - Khong tra loi";
    else if (status == 'rejected') text += " - Da tu choi";
    else text += " - ${formatDuration(duration)}";

    await convRef.collection('messages').add({
      'senderId': _myId,
      'text': text,
      'type': isVideo ? 'video_call' : 'voice_call',
      'callStatus': status,
      'callDuration': duration,
      'timestamp': FieldValue.serverTimestamp(),
      'seen': false,
      'isCallMessage': true,
    });

    await convRef.update({
      'lastMessage': text,
      'lastMessageTime': FieldValue.serverTimestamp(),
      'lastSenderId': _myId,
      'unreadCount.$otherUserId': FieldValue.increment(1),
    });
  }

  // -- Helpers --
  void toggleMute() {
    isMuted.value = !isMuted.value;
    engine?.muteLocalAudioStream(isMuted.value);
  }

  void toggleCamera() {
    isCameraOff.value = !isCameraOff.value;
    engine?.muteLocalVideoStream(isCameraOff.value);
  }

  void toggleSpeaker() {
    isSpeaker.value = !isSpeaker.value;
    engine?.setEnableSpeakerphone(isSpeaker.value);
  }

  String formatDuration(int secs) {
    final m = secs ~/ 60;
    final s = secs % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  String get timerText => formatDuration(duration.value);
}
