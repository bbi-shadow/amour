import 'package:cloud_firestore/cloud_firestore.dart';

enum NotificationType { match, message, like, superLike, visit, system }

class NotificationModel {
  final String id;
  final String userId;         // Người nhận
  final String fromUserId;
  final String fromUserName;
  final String fromUserPhoto;
  final NotificationType type;
  final String title;
  final String body;
  final bool isRead;
  final DateTime? createdAt;
  final String? targetId;      // matchId / conversationId / etc.

  NotificationModel({
    required this.id,
    required this.userId,
    required this.fromUserId,
    this.fromUserName = '',
    this.fromUserPhoto = '',
    required this.type,
    required this.title,
    required this.body,
    this.isRead = false,
    this.createdAt,
    this.targetId,
  });

  factory NotificationModel.fromFirestore(DocumentSnapshot doc) {
    final d = (doc.data() as Map<String, dynamic>?) ?? {};
    return NotificationModel(
      id: doc.id,
      userId: d['userId']?.toString() ?? '',
      fromUserId: d['fromUserId']?.toString() ?? '',
      fromUserName: d['fromUserName']?.toString() ?? '',
      fromUserPhoto: d['fromUserPhoto']?.toString() ?? '',
      type: _parseType(d['type']),
      title: d['title']?.toString() ?? '',
      body: d['body']?.toString() ?? '',
      isRead: d['isRead'] == true,
      createdAt: d['createdAt'] is Timestamp ? (d['createdAt'] as Timestamp).toDate() : null,
      targetId: d['targetId']?.toString(),
    );
  }

  static NotificationType _parseType(dynamic raw) {
    switch (raw?.toString()) {
      case 'match': return NotificationType.match;
      case 'message': return NotificationType.message;
      case 'like': return NotificationType.like;
      case 'superLike': return NotificationType.superLike;
      case 'visit': return NotificationType.visit;
      default: return NotificationType.system;
    }
  }

  Map<String, dynamic> toMap() => {
    'userId': userId,
    'fromUserId': fromUserId,
    'fromUserName': fromUserName,
    'fromUserPhoto': fromUserPhoto,
    'type': type.name,
    'title': title,
    'body': body,
    'isRead': isRead,
    'createdAt': FieldValue.serverTimestamp(),
    'targetId': targetId,
  };
}
